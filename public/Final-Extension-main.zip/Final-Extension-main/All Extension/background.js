// Background script for event handling
chrome.runtime.onInstalled.addListener(() => {
    // Initialize storage with empty arrays
    chrome.storage.local.get(['trackedProducts'], (result) => {
      if (!result.trackedProducts) {
        chrome.storage.local.set({ 
          trackedProducts: {
            viewed: [],
            cart: [],
            purchased: []
          }
        });
      }
    });
  });
  
  // Listen for messages from content script
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'productAdded') {
      // You could add notification logic here if needed
    }
  });