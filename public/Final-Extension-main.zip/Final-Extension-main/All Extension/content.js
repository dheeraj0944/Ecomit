// Track product views
function trackProductView() {
    // Check if we're on a product page
    if (isProductPage()) {
      const productData = extractProductData();
      if (productData) {
        saveProduct(productData, 'viewed');
      }
    }
  }
  
  // Check if current page is a product page
  function isProductPage() {
    // Amazon product page detection
    if (window.location.hostname.includes('amazon')) {
      return document.getElementById('dp') !== null || 
             document.getElementById('productTitle') !== null;
    }
    
    // Flipkart product page detection
    if (window.location.hostname.includes('flipkart')) {
      return document.querySelector('[itemprop="name"]') !== null;
    }
    
    return false;
  }
  
  // Extract product data from page
  function extractProductData() {
    let productData = {
      id: '',
      title: '',
      price: '',
      image: '',
      url: window.location.href,
      site: window.location.hostname,
      timestamp: new Date().toISOString()
    };
    
    // Amazon product data extraction
    if (window.location.hostname.includes('amazon')) {
      productData.id = document.getElementById('ASIN')?.value || 
                      new URLSearchParams(window.location.search).get('asin') || 
                      window.location.pathname.split('/')[3] || 
                      'amazon-' + Date.now();
      
      productData.title = document.getElementById('productTitle')?.textContent.trim() || 
                         document.querySelector('#title span')?.textContent.trim() || 
                         '';
      
      const priceElement = document.querySelector('.a-price .a-offscreen') || 
                          document.querySelector('.priceToPay span') ||
                          document.querySelector('.a-color-price');
      productData.price = priceElement?.textContent.trim() || '';
      
      const imageElement = document.querySelector('#landingImage') || 
                          document.querySelector('#imgBlkFront') ||
                          document.querySelector('.a-dynamic-image');
      productData.image = imageElement?.src || '';
    }
    
    // Flipkart product data extraction
    else if (window.location.hostname.includes('flipkart')) {
      productData.id = window.location.pathname.split('/')[1] || 'flipkart-' + Date.now();
      
      productData.title = document.querySelector('[itemprop="name"]')?.textContent.trim() || '';
      
      const priceElement = document.querySelector('._30jeq3') || 
                          document.querySelector('._16Jk6d');
      productData.price = priceElement?.textContent.trim() || '';
      
      const imageElement = document.querySelector('._396cs4') || 
                          document.querySelector('.CXW8mj img');
      productData.image = imageElement?.src || '';
    }
    
    // Validate we have at least a title and image
    if (!productData.title || !productData.image) return null;
    
    return productData;
  }
  
  // Save product to storage
  function saveProduct(productData, type = 'viewed') {
    chrome.storage.local.get(['trackedProducts'], function(result) {
      const products = result.trackedProducts || { viewed: [], cart: [], purchased: [] };
      
      // Check if product already exists in any category
      const existingIndex = products[type].findIndex(p => p.id === productData.id);
      
      if (existingIndex === -1) {
        // Add new product
        products[type].unshift(productData); // Add to beginning of array
        
        // Limit to 100 products per category
        if (products[type].length > 100) {
          products[type].pop();
        }
        
        chrome.storage.local.set({ trackedProducts: products });
      }
    });
  }
  
  // Track add to cart events
  function trackAddToCart() {
    // Amazon add to cart button
    document.addEventListener('click', function(e) {
      let target = e.target;
      while (target && target !== document) {
        if (target.id === 'add-to-cart-button' || 
            target.id === 'add-to-cart-button-ubb' ||
            target.classList.contains('add-to-cart-button')) {
          const productData = extractProductData();
          if (productData) {
            saveProduct(productData, 'cart');
          }
          break;
        }
        target = target.parentNode;
      }
    });
    
    // Flipkart add to cart button
    document.addEventListener('click', function(e) {
      let target = e.target;
      while (target && target !== document) {
        if (target.textContent.includes('ADD TO CART') || 
            (target.classList.contains('_2KpZ6l') && target.textContent.includes('Cart'))) {
          const productData = extractProductData();
          if (productData) {
            saveProduct(productData, 'cart');
          }
          break;
        }
        target = target.parentNode;
      }
    });
  }
  
  // Initialize tracking
  function initTracking() {
    // Track initial product view
    trackProductView();
    
    // Track subsequent product views via URL changes (SPA navigation)
    let lastUrl = window.location.href;
    setInterval(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        trackProductView();
      }
    }, 500);
    
    // Track add to cart events
    trackAddToCart();
  }
  
  // Start tracking
  initTracking();