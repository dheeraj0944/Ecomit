document.addEventListener('DOMContentLoaded', function() {
    // Tab switching
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        
        document.querySelectorAll('.tab-content').forEach(content => {
          content.classList.remove('active');
        });
        document.getElementById(`${tab.dataset.tab}-tab`).classList.add('active');
        
        // Refresh the displayed products when switching tabs
        loadProducts(tab.dataset.tab);
      });
    });
  
    // Search functionality
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    
    searchBtn.addEventListener('click', performSearch);
    searchInput.addEventListener('keyup', (e) => {
      if (e.key === 'Enter') performSearch();
    });
  
    function performSearch() {
      const query = searchInput.value.toLowerCase();
      const activeTab = document.querySelector('.tab-btn.active').dataset.tab;
      const productCards = document.querySelectorAll(`#${activeTab}-products .product-card`);
      
      productCards.forEach(card => {
        const title = card.querySelector('.product-title').textContent.toLowerCase();
        if (title.includes(query)) {
          card.classList.remove('hidden');
        } else {
          card.classList.add('hidden');
        }
      });
    }
  
    // Load products from storage
    function loadProducts(type = 'viewed') {
      chrome.storage.local.get(['trackedProducts'], function(result) {
        const products = result.trackedProducts || {};
        const productList = document.getElementById(`${type}-products`);
        
        if (!products[type] || products[type].length === 0) {
          document.getElementById('empty-state').classList.remove('hidden');
          productList.innerHTML = '';
          return;
        }
        
        document.getElementById('empty-state').classList.add('hidden');
        productList.innerHTML = '';
        
        products[type].forEach(product => {
          const productCard = createProductCard(product, type);
          productList.appendChild(productCard);
        });
      });
    }
  
    // Create product card HTML
    function createProductCard(product, type) {
      const card = document.createElement('a');
      card.className = 'product-card';
      card.href = product.url;
      card.target = '_blank';
      
      card.innerHTML = `
        <img src="${product.image}" alt="${product.title}" class="product-image">
        <div class="product-info">
          <div class="product-title">${product.title}</div>
          <div class="product-price">${product.price || 'Price not available'}</div>
          <div class="product-meta">
            <span>${product.site}</span>
            <span>${new Date(product.timestamp).toLocaleDateString()}</span>
          </div>
          <div class="product-actions">
            ${type === 'viewed' ? `
              <button class="action-btn primary" data-id="${product.id}" data-action="add-to-cart">Add to Cart</button>
              <button class="action-btn" data-id="${product.id}" data-action="remove">Remove</button>
            ` : ''}
            ${type === 'cart' ? `
              <button class="action-btn primary" data-id="${product.id}" data-action="purchase">Mark Purchased</button>
              <button class="action-btn" data-id="${product.id}" data-action="remove">Remove</button>
            ` : ''}
            ${type === 'purchased' ? `
              <button class="action-btn" data-id="${product.id}" data-action="remove">Remove</button>
            ` : ''}
          </div>
        </div>
      `;
      
      // Add event listeners to buttons
      card.querySelectorAll('.action-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          handleProductAction(btn.dataset.action, product.id, type);
        });
      });
      
      return card;
    }
  
    // Handle product actions (add to cart, remove, etc.)
    function handleProductAction(action, productId, currentType) {
      chrome.storage.local.get(['trackedProducts'], function(result) {
        const products = result.trackedProducts || { viewed: [], cart: [], purchased: [] };
        
        let product;
        let sourceArray = products[currentType];
        let targetArray;
        
        // Find the product
        const productIndex = sourceArray.findIndex(p => p.id === productId);
        if (productIndex === -1) return;
        
        product = sourceArray[productIndex];
        
        // Perform the action
        switch (action) {
          case 'add-to-cart':
            targetArray = products.cart;
            sourceArray.splice(productIndex, 1);
            targetArray.push(product);
            break;
          case 'purchase':
            targetArray = products.purchased;
            sourceArray.splice(productIndex, 1);
            targetArray.push({ ...product, purchaseDate: new Date().toISOString() });
            break;
          case 'remove':
            sourceArray.splice(productIndex, 1);
            break;
        }
        
        // Save back to storage
        chrome.storage.local.set({ trackedProducts: products }, () => {
          // Refresh the current tab
          loadProducts(currentType);
          
          // If moving to another tab, refresh that tab's count in the UI
          if (action === 'add-to-cart' || action === 'purchase') {
            const targetTab = action === 'add-to-cart' ? 'cart' : 'purchased';
            const targetTabBtn = document.querySelector(`.tab-btn[data-tab="${targetTab}"]`);
            if (!targetTabBtn.classList.contains('active')) {
              // You could add a visual indicator here that the other tab has new items
            }
          }
        });
      });
    }
  
    // Initial load
    loadProducts('viewed');
  });